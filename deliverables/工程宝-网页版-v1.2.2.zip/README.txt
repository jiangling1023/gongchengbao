工程宝 网页版 v1.2.2
======================
v1.2.2 修复：弹窗「取消」/✕ 点不动问题（Windows Chrome/Edge 原生 select GDI 遮罩）
使用方法：双击 index.html 或 python -m http.server 8823
