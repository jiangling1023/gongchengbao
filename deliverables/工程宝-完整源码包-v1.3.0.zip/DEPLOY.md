工程宝 v1.3.0 - 云端同步版
=============================
新增功能：
1. 网页版接入 Supabase 云端数据库（完全免费）
2. 数据修改自动同步到云端，多端数据互通
3. 安卓端通过 JSON 导入导出与云端同步

快速部署步骤：
1. 打开 https://supabase.com 注册账号并创建项目
2. 将 supabase-schema.sql 粘贴到 SQL Editor 执行
3. 复制 Project URL 和 anon key，填入 web-app/index.html
4. 部署到 Cloudflare Pages（见 DEPLOY.md 详细说明）

免费额度：500MB 数据库 / 无限 API / 5GB 流量/月，小团队完全够用。
