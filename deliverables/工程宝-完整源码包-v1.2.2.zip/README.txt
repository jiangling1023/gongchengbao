工程宝 完整源码 v1.2.2
=========================
本次修复（v1.2.2）：
- 网页版：所有弹窗（设备/工单/个人中心等）的「取消」按钮与右上角 ✕ 均可正常关闭
  原因：Windows Chrome/Edge 上原生 <select> 用 OS GDI 绘制，会吞掉下方点击
  修复：openModal 打开前 blur 所有 select；modal 内加 mousedown capture 兜底关闭
- 安卓端：v1.2.0（已签名 APK）
